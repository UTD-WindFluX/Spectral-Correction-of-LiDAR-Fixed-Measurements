function [SCorr] = Correction_time_f(SUnc,fTh,Exp,Fsamp) %Matteo Puccioni, 05/14/2018; mxp174930@utdallas.edu
%Correction_time returns the corrected LiDAR signal in time starting from
%the uncorrected one and the fitting of the correction function. The
%procedure deals with the FFT of the uncorrected signal, the correction and
%the IFFT back in time without phase correction.
% INPUT
    %SUnc: Uncorrected signal IN TIME;
    %fTh:  corner frequency;
    %Exp: exponent of the LP filter
    %Fsamp: sampling frequency 
    %z: height
    %Umean: mean velocity
% OUTPUT
    %Corrected signal in time
%% Evaluation of the FFT
NL              = length(SUnc);                         %Number of frequencies
xdft            = fft(SUnc,NL);                         %Number of frequencies with unique energy content
PhaseVr         = angle(xdft);                          %Evaluation of phase
xdft            = xdft(1:floor(NL/2)+1);                %Fourier transform up to Nyquist value
psdx            = (1/(Fsamp*NL)) * abs(xdft).^2;        %PSD on [-Nyquist Nyquist]
psdx(2:end-1)   = 2*psdx(2:end-1);                      %PSD on [0 Nyquist]
freq            = 0:Fsamp/NL:Fsamp/2;                   %Frequencies [0 Nyquist]
%% Correction of the FFT
Phi     = @(x) (1 + (x/fTh).^Exp).^(-1);                %Function handle of the correction function
Corr    = Phi(freq);                                    %Evaluation of function handle
MxCorr  = psdx./(Corr);                                 %Correction of PSD
A1corr      = sqrt(0.5*Fsamp*NL*MxCorr);                %Corrected Fourier coefficients
A1corr(1)   = A1corr(1)/sqrt(0.5);
A1corr(end) = A1corr(end)/sqrt(0.5);
if isequal(mod(length(SUnc),2),1)                       %Distinguish the case of either odd or even length of the signal
    Acorr=[A1corr A1corr(end:-1:2)];
else
    Acorr=[A1corr A1corr(end-1:-1:2)];
end
Xcorr   = Acorr.*exp(1i*PhaseVr);               %FFT of corrected signal (no change in phase)
SCorr   = ifft(Xcorr,'symmetric');              %Inverse FFT of the corrected signal (back in time)
end