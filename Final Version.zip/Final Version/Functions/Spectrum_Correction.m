function [SCorr,SUncorr,Kaimal,Res,Corr,Phi] = Spectrum_Correction(SUncorr,k,k0,ExcludeFit) %Matteo Puccioni, 10/28/2019; mxp174930@utdallas.edu
    %Spectrum_correction04 retrieves the correct turbulence scaling of the LiDAR velocity
    %signal. First, a best fit through Kaimal expression is performed to get
    %the correct modeled behavior; then, the ratio between the LiDAR spectrum
    %and the Kaimal expression is evaluated and fitted with Mann's modeled
    %filter. Finally, The LiDAR spectrum is divided by the filter to get the
    %corrected scaling.

    % INPUT:
        %S: spectrum;
        %F: vector of frequencies
        %f0: lower bound of the excluded frequency bandwidth

    %OUTPUT
        %SCorr: corrected LiDAR spectrum
        %SUncorr: uncorrected LiDAR spectrum
        %Kaimal: Kaimal model
        %Res: Data structure sumamrizing the results (see below)
        %Corr: Low-pass filter
        %Phi: Function handle of the low-pass filter
        %% Kaimal fit
        k       = reshape(k,[],1);
        SUncorr = reshape(SUncorr,[],1);

        ExcludeKaimal   = find(k'>k0);                                                      %Find indeces of frequencies larger than f0 (bad LiDAR spectrum)
        
        [xData, yData]  = prepareCurveData( log(k), log(k.*(SUncorr)));                     %Prepare f and f*PSD for the fitting
        excludedPoints  = excludedata( xData, yData, 'Indices', ExcludeKaimal);             %Exclude f>f0 
        opts            = fitoptions( 'Method', 'NonlinearLeastSquares' );
        opts.Display    = 'Off';
        opts.Lower      = [0 0];                                                            %Lower values for A and B
        opts.StartPoint = [6.8 1];                                                          %Starting point for A and B (values taken from Worsnop et al., 2017, p. 10)
        opts.Exclude    = excludedPoints(2:end);

        Kaimalfit       = fittype('log(A*exp(x)./(1 + B*exp(x)).^(5/3))', 'independent', 'x', 'dependent', 'y' );  %Writing of the fitting expression (eq. (10) in Cheynet et al., 2017)
        [fitKaimal,~]   = fit( xData, yData, Kaimalfit, opts );                                     %Fitting over f=(0,f0)
        FitCoeff        = coeffvalues(fitKaimal);                                                   %Values of the coefficients
        A               = FitCoeff(1);                                                              %1st free coefficient
        B               = FitCoeff(2);                                                              %2nd free coefficient

        Kaimal          = A./(1 + B*k).^(5/3);                                                      %Expression of the fitted Kaimal's function
        Ratio           = SUncorr./Kaimal;                                                          %Ratio between uncorrected LiDAR spectrum and Kaimal expression
        Ratio(1)        = 1;
        %% Fitting of the Ratio LiDAR/Kaimal
        [xData, yData]  = prepareCurveData( k, log10(Ratio));                       %Prepare data for the fitting

        ft              = fittype( strcat('log10((1+(x/fTh).^alpha)^(-1))'), 'independent', 'x', 'dependent', 'y' );     %Modeled filter: [1 + (f/fTH)^alpha]^(-1)
        if ~isempty(ExcludeFit)
            ExcludeFitIdx   = find(xData>ExcludeFit);
        else
            ExcludeFitIdx = [];
        end
        excludedPoints  = excludedata( xData, yData, 'Indices', ExcludeFitIdx );                                            %Exclusion of noisy frequencies
        opts            = fitoptions( 'Method', 'NonlinearLeastSquares' );
        opts.Display    = 'Off';
        opts.Lower      = [0 0];                                                                    %Lower bounds
        opts.StartPoint = [1 2];                                                                    %Starting points
        opts.Upper      = [Inf 5];                                                                  %Upper bounds
        opts.Exclude    = excludedPoints;

        [Fitresult, ~]  = fit( xData, yData, ft, opts );
        coeff           = coeffvalues(Fitresult); 
        alpha           = coeff(1);                                                                %Threshold
        Th             = coeff(2);                                                                 %Exponent

        Phi             = @(x) (1+(x/Th).^alpha).^(-1);                                            %Filter's equation
        Corr            = Phi(k);                                                                  %Filter evaluated on the frequencies

        SCorr           = SUncorr./Corr;                                                           %Correction of the LiDAR spectrum: ratio between uncorrected spectrum and correction function 

        VarRaw  = bandpower(SUncorr,k,'psd');                                             %Variance of the raw signal
        VarCorr = bandpower(SCorr,k,'psd');                                               %Variance of the corrected signal

    if VarRaw >= VarCorr
        warning('The corrected variance is less or equal to the uncorrected one.');     %Check on the variance recovery
    end
    %% Data structure
    Res.A = A;                                                                          %First Kaimal coefficient
    Res.B = B;                                                                          %Second Kaimal coefficient
    Res.VarRaw = VarRaw;                                                                %Raw variance
    Res.VarCorr = VarCorr;                                                              %Corrected variance
    Res.Th = Th;                                                                        %Dimensional threshold frequency
    Res.alpha = alpha;                                                                  %Exponent
    Res.f0 = k0;                                                                        %threshold frequency for correction
end