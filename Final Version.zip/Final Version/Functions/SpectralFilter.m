function [Fx1L,PSD,PSD_HP,Vdt,Vsynoptic,Fx1L_LP] = SpectralFilter(V,Fsamp,A,Threshold)
    NS          = length(V);                            %Number of frequencies
    xdft        = fft(V-mean(V));                       %Remove average and calculate FFT
    xdft        = xdft(1:floor(NS/2)+1);                %FFT up to Nyquist

    Fx1L        = 0:Fsamp/NS:Fsamp/2;                   %Frequency bandwidth [0, Nyquist]
    
    xdftHP      = xdft;                                 %Initialization FFT high-pass filtered
    Filter      = @(x) 0.5*(1 + tanh(A*log(x/Threshold)));                  %Definition of cutoff high-pass filter as in Hu et al., JFM, 2020
    xdftHP      = reshape(xdft,1,[]).*Filter(reshape(Fx1L,1,[]));           %Sharp spectral filtering
    Fx1L_LP     = Fx1L(Fx1L>=Threshold);                %Select frequencies owning to filtered spectrum

    if isequal(mod(NS,2),1)                             %Distinguish the case of either odd or even length of the signal
        AHP=[xdftHP xdftHP(:,end:-1:2)];
    else
        AHP=[xdftHP xdftHP(:,end-1:-1:2)];
    end

    Vdt         = ifft(AHP,'symmetric');                %Inverse FFT of the corrected signal (back in time)
    Vsynoptic   = reshape(V,1,[]) - reshape(Vdt,1,[]);
%% Output
    PSD         = (1/(Fsamp*NS)) * abs(xdft).^2;        %Calculate unfiltered PSD
    PSD(2:end-1)= 2*PSD(2:end-1);

    PSD_HP      = (1/(Fsamp*NS)) * abs(xdftHP).^2;      %Calculate high-pass filtered PSD
    PSD_HP(2:end-1) = 2*PSD_HP(2:end-1);
end