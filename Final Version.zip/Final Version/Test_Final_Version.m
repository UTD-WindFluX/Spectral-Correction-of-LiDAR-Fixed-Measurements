clear
close all
clc
addpath ./Functions 
load('Signal.mat');
%% Spectral correction
    %Set options
    options.Denoise                                 = 0;
    options.DenoiseLevel                            = 10;
    options.ExcludeFit                              = [];
    options.FilterSharpness                         = 100;
    options.WelchOverlap                            = 1;

    %Run the correction function
    [Correction,Spectrum,Variance,Velocity]         = Correction_Final(Signal.Fsamp,Signal.GL,0.001,Signal.V,Signal.z,options);

    %Collect the results
    PSD_Uncorr          = Spectrum.Uncorrected.PSD_k;   %Uncorrected spectrum
    PSD_Corr            = Spectrum.Corrected.PSD_k;     %Corrected spectrum
    f                   = Spectrum.frequency;
    k                   = Spectrum.wavenumber;          %Wavenumber vector
    n                   = Spectrum.frequency_red;
    kTh                 = Correction.kTh;               %Cutoff wavenumber
    Var_uncorr          = Variance.Uncorrected;         %Uncorrected variance
    Var_corr            = Variance.Corrected;           %Corrected variance
%% Summarizing figure
close all
figure('name','Spectral Correction','PaperPositionMode','auto','Units','normalized','Position',[0 0 0.75 0.5]), 
s1      = subplot(1,2,1);
        loglog(k,k.*PSD_Uncorr,'Color','b','LineWidth',2)
hold on,loglog(k,k.*PSD_Corr,'Color','k','LineWidth',2)
hold on,loglog(k,k.*Correction.Kaimal.wavenum,'Color','r','LineWidth',2)
hold on,line([Correction.kTh Correction.kTh],[1e-04 1],'color','k','linestyle','--','linewidth',2)
xlabel('$k~[1/m]$','Interpreter','latex');
ylabel('$kS_L(k)~[m^3/s^2]$','Interpreter','latex');
axis square
s1.FontSize     = 20;
s1.FontName     = 'times';

leg             = legend('LiDAR PSD uncorrected','LiDAR PSD corrected','Kaimal spectrum','Cutoff wavenumber');
leg.FontSize    = 20;
leg.FontName    = 'times';
leg.Position    = [0.2    0.2    0.1    0.08];
%
s2              = subplot(1,2,2);
        loglog(k,Correction.Ratio,'b','LineWidth',2)
hold on,loglog([k(k<=Correction.kTh) k(k>Correction.kTh)],[ones(1,length(k(k<=Correction.kTh))) (k(k>Correction.kTh)/Correction.kTh).^-Correction.Alpha] ,'k--','LineWidth',2);
hold on,loglog(k,Correction.Phi,'r','LineWidth',2)
xlabel('$k~[1/m]$','Interpreter','latex');
ylabel('$|\varphi(k)|^2$','Interpreter','latex');
axis square
s2.FontSize     = 20;
s2.FontName     = 'times';
leg             = legend('LiDAR-to-Kaimal ratio','Asymptotic behavior','Low-pass filter model');
leg.FontSize    = 20;
leg.FontName    = 'times';
leg.Position    = [0.65    0.18    0.1    0.08]; 