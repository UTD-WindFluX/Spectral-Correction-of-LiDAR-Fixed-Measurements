function [Correction,Spectrum,Variance,Velocity]         = Correction_Final(Fsamp,GL,Threshold,V,z,varargin)
%%Code to correct the turbulence energy spectrum of a single LiDAR gate
%%acquisition (see Puccioni, M. and Iungo, G. V.: "Spectral correction of turbulent energy damping on wind LiDAR measurements due to range-gate averaging", AMTD, 2020.)

%%Contacts: Matteo.Puccioni@utdallas.edu; Valerio.Iungo@utdallas.edu

%%Input:
    % Fsamp: Sampling frequency of the LiDAR signal (Hz)
    % GL: Gate length of the LiDAR signal (Hz)
    % Threshold: high-pass frequency for the spectral detrending (Hz)
    % V: gate velocity signal (m/s)
    % z: Height above the ground of the gate signal (m)
    % options: Data structure with user-defined options:
        % FilterSharpness: Sharp factor of the spectral filter (defined as per Eq. A2 in Hu et al. (2020)) (default value: 100)
        % DenoiseLevel: Level of the wavelet decomposition of the signal for the denoise procedure (default value: 10)
        % Denoise: binary value: 1 - Denoise the signal through a wavelet-based decomposition; 0 - do not denoise the signal default value: (1)
        % WelchOverlap: Set the number of samples overlapped during the Welch ensemble-averaging of the spectrum (default value: 1)
        % ExcludeFit: minimum frequency excluded from the best-fit of the spectral filter due to residual noise level (default value: [])
        % Frequency: specify the discrete frequency interval over which perform the spectral correction (default: threshold to Nyquist value)
        
%%Output:
    % Correction: Data structure containing the main parameter for the correction procedure:
        %.Kaimal_wavenum: Kaimal model tuned on the LiDAR spectrum as a function of wavenumber
        %.Kaimal_freq: Kaimal model tuned on the LiDAR spectrum as a function of frequency
        %.Kaimal_red_freq: Kaimal model tuned on the LiDAR spectrum as a function of reduced frequency (freq*z/Umean)
        %.Ratio: LiDAR-to-Kaimal ratio
        %.Phi: modeled LiDAR-to-Kaimal ration
        %.kTh: estimated cutoff wavenumber(1/m)
        %.Alpha: filter's order
        
    % Spectrum: Data structure with the turbulence spectrum:
        %.frequency: discrete frequency distribution (Hz)
        %.wavenumber: discrete wavenumber distribution (1/m) (calculated from frequency through Taylor hypothesis)
        %.frequency_red: reduced frequency: n = f*z/U
        %.Uncorrected: turbulence spectrum before correction:
            %PSD_f: power-spectral-density as a function of frequency
            %PSD_k: power-spectral-density as a function of wavenumber
            %PSD_n: power-spectral-density as a function of reduced frequency
        %.Corrected: turbulence spectrum after correction
    
    %Variance: Data structure containing the variance before and after the correction
        %.Uncorrected: Variance before the correction
        %.Corrected: Variance after the correction
    
    %Velocity: Data structure containing information about the detrend
        %.Detrend: detrended velocity signal
            %.Uncorrected: before spectral correction
            %.Corrected: after spectral correction
        %.Trend: long-term trend (filtered out from the detrending procedure)
        %.Mean: mean velocity value
    %% Set user-defined options
    if isempty(varargin)    
        defaultOptions;
    else
        options             = varargin{1};
        prepareOptionsCorrection;
    end
    Umean                   = mean(V);                                              %Calculate mean velocity

    [~,~,~,Vdt,Vresidual,~] = SpectralFilter(Vdenoise,Fsamp,A,Threshold); %Spectral detrending
        
    %Evaluate discrete frequency values
    if ~isempty(varargin)
        if isfield(options,'Frequency')
            F           = options.Frequency;
            if max(F>0.5*Fsamp)
                warning('The maximum selected frequency is greater than half of the sampling rate.');
            end
        else
            F           = logspace(log10(Threshold),log10(0.5*Fsamp),floor(length(Vdenoise)/2+1));
        end
    else
        F           = logspace(log10(Threshold),log10(0.5*Fsamp),floor(length(Vdenoise)/2+1));
    end
    %Calculate turbulence spectrum in frequency
    PSD             = pwelch(Vdt,floor(Fsamp/Threshold),Overlap,F,Fsamp);

    n               = F*z/Umean;                                    %reduced frequency
    k               = 2*pi*F/Umean;                                 %1/m, wavenumber
    PSDk            = PSD*Umean/(2*pi);                             %Uncorrected spectrum in wavenumber
    PSDn            = Umean*PSD/z;                                  %Uncorrected spectrum in reduced frequency
    %% Spectral correction
    kTh0            = 2*pi/GL;                                      %Initial guess for kTh
    DeltakTh        = 100;                                          %Initialization of error on kTh
    N               = 0;
    while DeltakTh>1 && N<100
        [PSDCorr_k,~,Kaimal,Res,Corr,~]         = Spectrum_Correction(PSDk,k,kTh0,2*pi*ExcludeFit/Umean);   %Spectral correction
        kTh                                     = Res.Th;                               %Estimated cutoff frequency
        DeltakTh                                = abs(kTh-kTh0)/kTh0*100;               %Evaluation of percentage difference of cutoff value
        kTh0                                    = kTh;                                  %Updated value
        kMin                                    = 3/(2*Res.B);                          %Wavenumber associated to the Kaimal peak
        if kTh<=kMin
           warning('The cutoff wavenumber is equal or less than the peak wavenumber'); 
        end
        N   = N + 1;
    end
    
    PSDCorr_f       = PSDCorr_k*2*pi/Umean;                                             %Calculation of the corrected spectrum in frequency
    PSDCorr_n       = PSDCorr_f*Umean/z;                                                 %Calculation of the corrected spectrum in reduced frequency
    
    [V_corr]        = Correction_time_f(Vdt,Umean*kTh/(2*pi),Res.alpha,Fsamp);          %Evaluation of the corrected signal in time
    if ~isempty(ExcludeFit)
        [~,~,~,~,V_corr,~]              = SpectralFilter(V_corr,Fsamp,A,ExcludeFit);    %Remove noisy component from the signal through a sharp spectral filtering
    end
    %% Save results in data structures
    Velocity.Detrend.Uncorrected        = Vdt;
    Velocity.Trend                      = Vresidual;
    Velocity.Mean                       = Umean;
    Velocity.Detrend.Corrected          = V_corr;
    
    
    Correction.Kaimal.wavenum           = reshape(Kaimal,1,[]);
    Correction.Kaimal.freq              = reshape(Kaimal*2*pi/Umean,1,[]);
    Correction.Kaimal.red_freq          = reshape(Kaimal*2*pi/z,1,[]);
    Correction.Ratio                    = PSDk./Correction.Kaimal.wavenum;
    Correction.Phi                      = Corr;
    Correction.kTh                      = kTh;
    Correction.Alpha                    = Res.alpha;
    
    Spectrum.frequency      = F;
    Spectrum.wavenumber     = k;
    Spectrum.frequency_red  = n;
    Spectrum.Uncorrected.PSD_f          = PSD;
    Spectrum.Uncorrected.PSD_k          = PSDk;
    Spectrum.Uncorrected.PSD_n          = PSDn;
    Spectrum.Corrected.PSD_f    = reshape(PSDCorr_f,1,[]);
    Spectrum.Corrected.PSD_k    = reshape(PSDCorr_k,1,[]);
    Spectrum.Corrected.PSD_n    = reshape(PSDCorr_n,1,[]);
    
    Variance.Uncorrected    = var(Vdt);
    Variance.Corrected      = var(V_corr);
end