A                           = 100;
Vdenoise                    = wdenoise(V,10,'Wavelet','sym10');
Overlap                     = 1;
ExcludeFit                  = [];

