if isfield(options,'FilterSharpness')
    A   = options.FilterSharpness;
else
    A   = 100;
end
if isfield(options,'DenoiseLevel')
    DenoiseLevel        = options.DenoiseLevel;
else
    DenoiseLevel        = 10;
end
if isfield(options,'Denoise') && isequal(options.Denoise,1)
    Vdenoise            = wdenoise(V,10,'Wavelet','sym10');
else
    Vdenoise            = V;
end

if isfield(options,'WelchOverlap')
    Overlap             = options.WelchOverlap;
else
    Overlap             = 1;
end

if isfield(options,'ExcludeFit')
    ExcludeFit          = options.ExcludeFit;
else
    ExcludeFit          = [];
end